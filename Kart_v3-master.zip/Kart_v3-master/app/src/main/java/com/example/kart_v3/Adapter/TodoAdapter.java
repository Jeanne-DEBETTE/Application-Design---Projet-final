package com.example.kart_v3.Adapter;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.CheckBox;

import androidx.recyclerview.widget.RecyclerView;

import com.example.kart_v3.MainActivity;
import com.example.kart_v3.Model.TodoModel;
import com.example.kart_v3.R;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class TodoAdapter extends RecyclerView.Adapter<TodoAdapter.ViewHolder> {

    private List<TodoModel> todoList;
    private MainActivity activity;

    public TodoAdapter(MainActivity activity){
        this.activity = activity;
    }

    public RecyclerView.ViewHolder on CreateViewHolder(ViewGroup parent, int ViewType){
        View itemView = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.task_layout, parent, false);
        return new RecyclerView.ViewHolder(itemView);

    }

    public void onBindViewHolder (ViewHolder holder, int position){
        TodoModel item = todoList.get(position);
        holder.task.setText(item.getTask());
        holder.task.setChecked(toBoolean(item.getStatus()));
    }

    public int getItemCount(){
        return todoList.size();
    }

    private boolean toBoolean(int n){
        return n!=0;
    }

    public void setTasks(List<TodoModel> todoList){
        this.todoList = todoList;
        notifyDataSetChanged();
    }
    public static class ViewHolder extends RecyclerView.ViewHolder{
        CheckBox task;
        ViewHolder(android.view.View view){
            super(view);
            task = android.view.View.findViewById(R.id.todoCheckBox);
        }
    }

}
